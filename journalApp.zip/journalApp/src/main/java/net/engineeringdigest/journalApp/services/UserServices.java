package net.engineeringdigest.journalApp.services;

import net.engineeringdigest.journalApp.entity.JournalEntry;
import net.engineeringdigest.journalApp.entity.User;
import net.engineeringdigest.journalApp.repository.UserRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class UserServices {

    @Autowired
    private UserRepository userRepository;

   public void saveEntry(User user){ // to create entry
       userRepository.save(user);


   }

    public List<User> getAll() { // to cehck what all entries are prezent
       return userRepository.findAll();
    }

    public Optional<User>findById(ObjectId id){ // to find entry by number
       return userRepository.findById(id);
    }

    public void deleteById(ObjectId id){
       userRepository.deleteById(id);
    }

    public User findByUserName(String userName){
       return userRepository.findByUserName(userName);
    }

}
